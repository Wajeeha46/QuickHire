package com.example.quickhire;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.HashMap;
import java.util.Map;

public class SignupActivity extends AppCompatActivity {

    private EditText emailEditText, passwordEditText, repeatPasswordEditText;
    private Button signupButton;
    private TextView loginRedirectText;
    private FirebaseAuth mAuth;
    private FirebaseFirestore db;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("Please wait");
        progressDialog.setMessage("Creating your account...");
        progressDialog.setCancelable(false);

        emailEditText = findViewById(R.id.etEmail);
        passwordEditText = findViewById(R.id.etpassword);
        repeatPasswordEditText = findViewById(R.id.et_repeat_password);
        signupButton = findViewById(R.id.btnsignup);
        loginRedirectText = findViewById(R.id.tv_login);

        signupButton.setOnClickListener(v -> {
            String email = emailEditText.getText().toString().trim();
            String password = passwordEditText.getText().toString().trim();
            String repeatPassword = repeatPasswordEditText.getText().toString().trim();

            if (validateInputs(email, password, repeatPassword)) {
                signUpUser(email, password);
            }
        });

        // Already have an account? Login redirect
        loginRedirectText.setOnClickListener(v -> {
            startActivity(new Intent(SignupActivity.this, LoginActivity.class));
            finish();
        });
    }

    private boolean validateInputs(String email, String password, String repeatPassword) {
        if (email.isEmpty()) {
            emailEditText.setError("Email is required");
            return false;
        }
        if (password.isEmpty()) {
            passwordEditText.setError("Password is required");
            return false;
        }
        if (password.length() < 6) {
            passwordEditText.setError("Password must be ≥6 characters");
            return false;
        }
        if (!password.equals(repeatPassword)) {
            repeatPasswordEditText.setError("Passwords must match");
            return false;
        }
        return true;
    }

    private void signUpUser(String email, String password) {
        progressDialog.show();

        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        FirebaseUser user = mAuth.getCurrentUser();
                        if (user != null) {
                            user.sendEmailVerification()
                                    .addOnCompleteListener(emailTask -> {
                                        if (!emailTask.isSuccessful()) {
                                            Log.w("Signup", "Failed to send verification", emailTask.getException());
                                        }
                                    });

                            saveUserToFirestore(user.getUid(), email);
                            startActivity(new Intent(SignupActivity.this, MainPageActivity.class));
                            finish();
                        }
                    } else {
                        progressDialog.dismiss();
                        Toast.makeText(this, "Signup failed: " +
                                task.getException().getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
    }

    private void saveUserToFirestore(String userId, String email) {
        Map<String, Object> user = new HashMap<>();
        user.put("email", email);
        user.put("createdAt", FieldValue.serverTimestamp());
        user.put("verified", false);

        db.collection("users").document(userId)
                .set(user)
                .addOnFailureListener(e -> Log.w("Signup", "Error saving user", e));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (progressDialog != null && progressDialog.isShowing()) {
            progressDialog.dismiss();
        }
    }
}