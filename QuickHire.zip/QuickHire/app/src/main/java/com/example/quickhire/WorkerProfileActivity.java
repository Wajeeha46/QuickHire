package com.example.quickhire;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.example.quickhire.models.Worker;
import com.google.firebase.firestore.FirebaseFirestore;

public class WorkerProfileActivity extends AppCompatActivity {
    private Worker worker;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_worker_profile);

        db = FirebaseFirestore.getInstance();
        worker = (Worker) getIntent().getSerializableExtra("worker");

        if (worker == null) {
            Toast.makeText(this, R.string.worker_data_unavailable, Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        ImageView workerImage = findViewById(R.id.workerImage);
        TextView nameText = findViewById(R.id.nameText);
        TextView categoryText = findViewById(R.id.categoryText);
        RatingBar ratingBar = findViewById(R.id.ratingBar);
        TextView rateText = findViewById(R.id.rateText);
        Button hireButton = findViewById(R.id.hireButton);
        View availabilityDot = findViewById(R.id.availabilityDot);

        Glide.with(this)
                .load(worker.getImageUrl())
                .placeholder(R.drawable.worker_placeholder)
                .into(workerImage);

        nameText.setText(worker.getName());
        categoryText.setText(worker.getCategory());
        ratingBar.setRating((float) worker.getRating());
        rateText.setText(getString(R.string.hourly_rate_format, worker.getHourlyRate()));

        if (worker.isAvailable()) {
            availabilityDot.setBackgroundResource(R.drawable.available_dot);
            hireButton.setEnabled(true);
            hireButton.setOnClickListener(v -> hireWorker());
        } else {
            availabilityDot.setBackgroundResource(R.drawable.unavailable_dot);
            hireButton.setEnabled(false);
            hireButton.setText(R.string.already_hired);
        }
    }

    private void hireWorker() {
        db.collection("workers")
                .document(worker.getId())
                .update("available", false)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(this, getString(R.string.hiring_success, worker.getName()), Toast.LENGTH_SHORT).show();
                    finish();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, getString(R.string.hiring_failed, e.getMessage()), Toast.LENGTH_SHORT).show();
                });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    // Add this method to handle back button press
    @Override
    public void onBackPressed() {
        // Go back to CategoriesActivity
        super.onBackPressed(); // This will handle the back navigation properly
    }

}