package com.example.quickhire;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class AboutUsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_us);

        TextView aboutText = findViewById(R.id.aboutText);
        aboutText.setText(
                "Welcome to QuickHire!\n\n" +
                        "QuickHire is the fastest way to connect with skilled professionals for all your short-term service needs.\n\n" +
                        "Key Features:\n" +
                        "• Instant access to verified professionals\n" +
                        "• Simple and secure hiring process\n" +
                        "• Multiple service categories\n" +
                        "• Real-time availability tracking\n\n" +
                        "Our Mission:\n" +
                        "To revolutionize the service industry by providing a seamless connection between customers and professionals.\n\n" +
                        "Version: 1.0\n" +
                        "© 2023 QuickHire Team"
        );
    }
}