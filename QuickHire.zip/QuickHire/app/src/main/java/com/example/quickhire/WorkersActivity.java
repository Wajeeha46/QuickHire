package com.example.quickhire;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.quickhire.adapters.WorkerAdapter;
import com.example.quickhire.models.Worker;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import java.util.ArrayList;
import java.util.List;

public class WorkersActivity extends AppCompatActivity implements WorkerAdapter.OnWorkerClickListener {

    private WorkerAdapter adapter;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_workers);

        String category = getIntent().getStringExtra("category");
        setTitle(category);

        db = FirebaseFirestore.getInstance();
        RecyclerView recyclerView = findViewById(R.id.workersRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Fixed: Added context as first parameter
        adapter = new WorkerAdapter(this, new ArrayList<>(), this);
        recyclerView.setAdapter(adapter);

        loadWorkers(category);
    }

    private void loadWorkers(String category) {
        db.collection("workers")
                .whereEqualTo("category", category)
                .whereEqualTo("available", true)  // Added to only show available workers
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful() && task.getResult() != null) {
                        List<Worker> workers = new ArrayList<>();
                        for (QueryDocumentSnapshot document : task.getResult()) {
                            Worker worker = document.toObject(Worker.class);
                            worker.setId(document.getId());
                            workers.add(worker);
                        }
                        adapter.updateWorkers(workers);
                    }
                });
    }

    @Override
    public void onWorkerClick(Worker worker) {
        Intent intent = new Intent(this, WorkerProfileActivity.class);
        intent.putExtra("worker", worker);
        startActivity(intent);
    }
}