package com.example.quickhire.models;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class HireRequest {
    private String customerName;
    private String address;
    private int hours;
    private String phone;
    private String email;
    private String workerId;
    private Date createdAt;
    private String hireId;  // Added for easier reference

    // Required empty constructor for Firebase
    public HireRequest() {
        this.createdAt = new Date();
    }



    public HireRequest(String customerName, String address, int hours,
                       String phone, String email, String workerId) {
        this.customerName = customerName;
        this.address = address;
        this.hours = hours;
        this.phone = phone;
        this.email = email;
        this.workerId = workerId;
        this.createdAt = new Date();
    }

    // Convert to Map for Firebase
    public Map<String, Object> toMap() {
        Map<String, Object> result = new HashMap<>();
        result.put("customerName", customerName);
        result.put("address", address);
        result.put("hours", hours);
        result.put("phone", phone);
        result.put("email", email);
        result.put("workerId", workerId);
        result.put("createdAt", createdAt);
        result.put("hireId", hireId);
        return result;
    }

    // Getters and Setters
    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getHours() {
        return hours;
    }

    public void setHours(int hours) {
        this.hours = hours;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getWorkerId() {
        return workerId;
    }

    public void setWorkerId(String workerId) {
        this.workerId = workerId;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public String getHireId() {
        return hireId;
    }

    public void setHireId(String hireId) {
        this.hireId = hireId;
    }
}