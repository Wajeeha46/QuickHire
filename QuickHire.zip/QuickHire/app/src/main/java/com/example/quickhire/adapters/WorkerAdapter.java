package com.example.quickhire.adapters;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.app.Activity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.example.quickhire.R;
import com.example.quickhire.HireFormActivity;
import com.example.quickhire.WorkerProfileActivity;
import com.example.quickhire.models.Worker;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class WorkerAdapter extends RecyclerView.Adapter<WorkerAdapter.ViewHolder> {
    private static final String TAG = "WorkerAdapter";
    private List<Worker> workers;
    private final Context context;
    private final OnWorkerClickListener listener;

    public interface OnWorkerClickListener {
        void onWorkerClick(Worker worker);
    }

    public WorkerAdapter(Context context, List<Worker> workers, OnWorkerClickListener listener) {
        this.context = context;
        this.workers = workers != null ? workers : new ArrayList<>();
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_worker, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Worker worker = workers.get(position);
        if (worker == null) {
            Log.w(TAG, "Worker object is null at position: " + position);
            return;
        }

        holder.workerName.setText(worker.getName() != null ? worker.getName() : "Unknown Worker");
        holder.workerRating.setText(String.format(Locale.getDefault(), "%.1f", worker.getRating()));
        holder.workerRate.setText(String.format(Locale.getDefault(), "%.0f PKR/hr", worker.getHourlyRate()));
        holder.availabilityDot.setVisibility(worker.isAvailable() ? View.VISIBLE : View.GONE);
        holder.hireButton.setVisibility(worker.isAvailable() ? View.VISIBLE : View.GONE);
        holder.hireButton.setEnabled(worker.isAvailable());

        try {
            String imageUrl = worker.getImageUrl();
            if (imageUrl != null && !imageUrl.isEmpty()) {
                Glide.with(holder.itemView.getContext())
                        .load(imageUrl)
                        .placeholder(R.drawable.worker_placeholder)
                        .error(R.drawable.error_placeholder)
                        .into(holder.workerImage);
            } else {
                holder.workerImage.setImageResource(R.drawable.worker_placeholder);
            }
        } catch (Exception e) {
            holder.workerImage.setImageResource(R.drawable.error_placeholder);
        }

        holder.hireButton.setOnClickListener(v -> {
            Intent intent = new Intent(context, HireFormActivity.class);
            intent.putExtra("worker", worker);
           // intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
            // Add transition animation
            ((Activity)context).overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);

        });

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onWorkerClick(worker);
            } else {
                Intent intent = new Intent(context, WorkerProfileActivity.class);
                intent.putExtra("worker", worker);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return workers.size();
    }

    public void updateWorkers(List<Worker> newWorkers) {
        this.workers = newWorkers != null ? newWorkers : new ArrayList<>();
        notifyDataSetChanged();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        final ImageView workerImage;
        final View availabilityDot;
        final TextView workerName;
        final TextView workerRating;
        final TextView workerRate;
        final Button hireButton;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            workerImage = itemView.findViewById(R.id.workerImage);
            availabilityDot = itemView.findViewById(R.id.availabilityDot);
            workerName = itemView.findViewById(R.id.workerName);
            workerRating = itemView.findViewById(R.id.workerRating);
            workerRate = itemView.findViewById(R.id.workerRate);
            hireButton = itemView.findViewById(R.id.hireButton);
        }
    }
}