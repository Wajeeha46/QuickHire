package com.example.quickhire.models;

import java.io.Serializable;
import java.util.Date;

public class Worker implements Serializable {
    private String id;
    private String name;
    private String category;
    private String imageUrl;
    private double rating;
    private double hourlyRate; // Storing PKR values
    private boolean available;
    private Date createdAt;

    // Required empty constructor for Firestore
    public Worker() {}

    // Constructor for creating new workers
    public Worker(String name, String category, String imageUrl,
                  double rating, double hourlyRate) {
        this.name = name;
        this.category = category;
        this.imageUrl = imageUrl;
        this.rating = rating;
        this.hourlyRate = hourlyRate;
        this.available = true;
        this.createdAt = new Date();
    }

    // Complete getters and setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }

    public double getRating() { return rating; }
    public void setRating(double rating) { this.rating = rating; }

    public double getHourlyRate() { return hourlyRate; }
    public void setHourlyRate(double hourlyRate) { this.hourlyRate = hourlyRate; }

    public boolean isAvailable() { return available; }
    public void setAvailable(boolean available) { this.available = available; }

    public Date getCreatedAt() { return createdAt; }
    public void setCreatedAt(Date createdAt) { this.createdAt = createdAt; }
}