package com.example.quickhire;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.example.quickhire.R;
import com.example.quickhire.models.HireRequest;
import com.example.quickhire.models.Worker;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class HireFormActivity extends AppCompatActivity {
    private static final int LOCATION_PERMISSION_CODE = 1001;
    private EditText etName, etAddress, etHours, etPhone, etEmail;
    private Worker worker;
    private FusedLocationProviderClient fusedLocationClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hire_form);

        // Get worker from intent
        worker = (Worker) getIntent().getSerializableExtra("worker");
        if (worker == null) {
            Toast.makeText(this, "Worker information not available", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Initialize views
        etName = findViewById(R.id.etName);
        etAddress = findViewById(R.id.etAddress);
        etHours = findViewById(R.id.etHours);
        etPhone = findViewById(R.id.etPhone);
        etEmail = findViewById(R.id.etEmail);
        Button btnSubmit = findViewById(R.id.btnSubmit);
        Button btnUseCurrentLocation = findViewById(R.id.btnUseCurrentLocation);

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        // Location button click
        btnUseCurrentLocation.setOnClickListener(v -> getCurrentLocation());

        // Submit button click
        btnSubmit.setOnClickListener(v -> {
            if (validateForm()) {
                submitHireRequest();
            }
        });
    }

    private void getCurrentLocation() {
        if (checkLocationPermission()) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            fusedLocationClient.getLastLocation()
                    .addOnSuccessListener(this, location -> {
                        if (location != null) {
                            Geocoder geocoder = new Geocoder(this, Locale.getDefault());
                            try {
                                List<Address> addresses = geocoder.getFromLocation(
                                        location.getLatitude(),
                                        location.getLongitude(),
                                        1);
                                if (addresses != null && !addresses.isEmpty()) {
                                    etAddress.setText(addresses.get(0).getAddressLine(0));
                                } else {
                                    etAddress.setText(String.format(Locale.getDefault(),
                                            "Lat: %.6f, Lng: %.6f",
                                            location.getLatitude(),
                                            location.getLongitude()));
                                }
                            } catch (IOException e) {
                                etAddress.setText(String.format(Locale.getDefault(),
                                        "Lat: %.6f, Lng: %.6f",
                                        location.getLatitude(),
                                        location.getLongitude()));
                            }
                        } else {
                            Toast.makeText(this, "Unable to get current location", Toast.LENGTH_SHORT).show();
                        }
                    });
        }
    }

    private boolean checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    LOCATION_PERMISSION_CODE);
            return false;
        }
        return true;
    }

    private boolean validateForm() {
        boolean valid = true;

        String name = etName.getText().toString().trim();
        String address = etAddress.getText().toString().trim();
        String hours = etHours.getText().toString().trim();
        String phone = etPhone.getText().toString().trim();
        String email = etEmail.getText().toString().trim();

        if (name.isEmpty()) {
            etName.setError("Name is required");
            valid = false;
        }

        if (address.isEmpty()) {
            etAddress.setError("Address is required");
            valid = false;
        }

        if (hours.isEmpty()) {
            etHours.setError("Hours required");
            valid = false;
        } else {
            try {
                int hoursValue = Integer.parseInt(hours);
                if (hoursValue <= 0) {
                    etHours.setError("Must be greater than 0");
                    valid = false;
                }
            } catch (NumberFormatException e) {
                etHours.setError("Invalid number");
                valid = false;
            }
        }

        if (phone.isEmpty()) {
            etPhone.setError("Phone required");
            valid = false;
        } else if (!Patterns.PHONE.matcher(phone).matches()) {
            etPhone.setError("Invalid phone number");
            valid = false;
        }

        if (email.isEmpty()) {
            etEmail.setError("Email required");
            valid = false;
        } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etEmail.setError("Invalid email format");
            valid = false;
        }

        return valid;
    }

    private void submitHireRequest() {

        // Validate first
        if (!validateForm()) {
            Toast.makeText(this, "Please correct the form errors", Toast.LENGTH_SHORT).show();
            return;
        }


        DatabaseReference database = FirebaseDatabase.getInstance().getReference();
        String hireId = database.child("hires").push().getKey();

        HireRequest hireRequest = new HireRequest(
                etName.getText().toString().trim(),
                etAddress.getText().toString().trim(),
                Integer.parseInt(etHours.getText().toString()),
                etPhone.getText().toString().trim(),
                etEmail.getText().toString().trim(),
                worker.getId()
        );

        database.child("hires").child(hireId).setValue(hireRequest)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        // Mark worker as unavailable
                        database.child("workers").child(worker.getId())
                                .child("available").setValue(false)
                                .addOnCompleteListener(updateTask -> {
                                    if (updateTask.isSuccessful()) {
                                        Toast.makeText(HireFormActivity.this,
                                                "Worker hired successfully!",
                                                Toast.LENGTH_SHORT).show();
                                        finish();
                                    } else {
                                        Toast.makeText(HireFormActivity.this,
                                                "Failed to update worker status",
                                                Toast.LENGTH_SHORT).show();
                                    }
                                });
                    } else {
                        Toast.makeText(HireFormActivity.this,
                                "Failed to create hire request",
                                Toast.LENGTH_SHORT).show();
                    }
                });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getCurrentLocation();
            } else {
                Toast.makeText(this, "Location permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}