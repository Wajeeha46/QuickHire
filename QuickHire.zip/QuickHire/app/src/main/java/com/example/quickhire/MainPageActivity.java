package com.example.quickhire;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainPageActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_page);

        // Initialize all three buttons
        Button categoriesButton = findViewById(R.id.categoriesButton);
        Button contactUsButton = findViewById(R.id.contactUsButton);
        Button aboutUsButton = findViewById(R.id.aboutUsButton);

        // Set click listeners
        categoriesButton.setOnClickListener(v -> {
            startActivity(new Intent(MainPageActivity.this, CategoriesActivity.class));
        });

        contactUsButton.setOnClickListener(v -> {
            startActivity(new Intent(MainPageActivity.this, ContactUsActivity.class));
        });

        aboutUsButton.setOnClickListener(v -> {
            startActivity(new Intent(MainPageActivity.this, AboutUsActivity.class));
        });
    }

  //  @Override
   // public void onBackPressed() {
        // Close app instead of going back to auth screens
      //  finishAffinity();
  //  }
}